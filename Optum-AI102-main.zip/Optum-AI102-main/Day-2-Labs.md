Day-2-Labs
1. https://github.com/MicrosoftLearning/mslearn-ai-language/blob/main/Instructions/Exercises/01-analyze-text.md
2. https://github.com/MicrosoftLearning/mslearn-ai-language/blob/main/Instructions/Exercises/06-translate-text.md
3. https://github.com/MicrosoftLearning/mslearn-ai-language/blob/main/Instructions/Exercises/03-language-understanding.md
