https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Instructions/Exercises/01-use-prebuilt-models.md

https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Instructions/Exercises/02-custom-document-intelligence.md

https://github.com/MicrosoftLearning/mslearn-ai-document-intelligence/blob/main/Instructions/Exercises/03-composed-model.md

https://github.com/MicrosoftLearning/mslearn-ai-services/blob/main/Instructions/Exercises/02-ai-services-security.md

https://github.com/MicrosoftLearning/mslearn-ai-services/blob/main/Instructions/Exercises/04-use-a-container.md

