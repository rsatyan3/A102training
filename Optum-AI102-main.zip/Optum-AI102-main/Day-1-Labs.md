Labs Day -1 

1. Install these in VDI (virtual desktop) given by Palmeto (Python only) https://github.com/MicrosoftLearning/mslearn-ai-services/blob/main/Instructions/setup.md

2. QnA Lab: https://github.com/MicrosoftLearning/mslearn-ai-language/blob/main/Instructions/Exercises/02-qna.md 

3. Key vault lab: https://github.com/MicrosoftLearning/mslearn-ai-services/blob/main/Instructions/Exercises/02-ai-services-security.md
