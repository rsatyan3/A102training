1. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/01-get-started-azure-openai.md
2. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/02-natural-language-azure-openai.md
3. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/03-prompt-engineering.md
4. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/04-code-generation.md
5. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/05-generate-images.md
6. https://github.com/MicrosoftLearning/mslearn-openai/blob/main/Instructions/Exercises/06-use-own-data.md
