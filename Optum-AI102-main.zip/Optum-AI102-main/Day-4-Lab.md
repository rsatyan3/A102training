Old vision portal labs 
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/03-custom-vision-object-detection.md
2. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/07-custom-vision-image-classification.md

New vision portal labs
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/02-image-classification.md

Video indexer 
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/06-video-indexer.md

Image analysis SDK
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/01-analyze-images.md

OCR 
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/05-ocr.md

Face detection 
1. https://github.com/azuredevops619/mslearn-ai-vision/blob/main/Instructions/Exercises/04-face-service.md
